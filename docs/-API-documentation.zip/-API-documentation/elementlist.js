
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","mysqli"],["c","mysqli_stmt"],["f","nl()"],["f","nlhr()"],["c","RTdev\\RTphp\\RTmysqli"],["c","RTdev\\RTphp\\RTpassword"],["c","RTdev\\RTphp\\RTslugify"],["c","RTdev\\RTphp\\RTutil"],["f","RTphpLoad()"]];
